import * as TaskModel from '../models/taskModel.js';

export const getTasks = (req, res) => {
    try {
        const tasks = TaskModel.getAllTasks();
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch tasks' });
    }
};

export const createTask = (req, res) => {
    try {
        const { title, status } = req.body;

        if (!title || !status) {
            return res.status(400).json({ error: 'Title and status are required' });
        }

        if (!['todo', 'in-progress', 'done'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status. Must be todo, in-progress, or done' });
        }

        const newTask = TaskModel.createTask(title, status);
        res.status(201).json(newTask);
    } catch (error) {
        res.status(500).json({ error: 'Failed to create task' });
    }
};

export const updateTask = (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!status) {
            return res.status(400).json({ error: 'Status is required' });
        }

        if (!['todo', 'in-progress', 'done'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status. Must be todo, in-progress, or done' });
        }

        const updatedTask = TaskModel.updateTaskStatus(id, status);

        if (!updatedTask) {
            return res.status(404).json({ error: 'Task not found' });
        }

        res.json(updatedTask);
    } catch (error) {
        res.status(500).json({ error: 'Failed to update task' });
    }
};