let tasks = [
    {
        id: 1,
        title: 'Setup project',
        status: 'done',
        createdAt: new Date().toISOString()
    },
    {
        id: 2,
        title: 'Build API',
        status: 'in-progress',
        createdAt: new Date().toISOString()
    }
];

let nextId = 3;

export const getAllTasks = () => {
    return tasks;
};

export const createTask = (title, status) => {
    const newTask = {
        id: nextId++,
        title,
        status,
        createdAt: new Date().toISOString()
    };
    tasks.push(newTask);
    return newTask;
};

export const findTaskById = (id) => {
    return tasks.find(task => task.id === parseInt(id));
};

export const updateTaskStatus = (id, status) => {
    const task = findTaskById(id);
    if (task) {
        task.status = status;
        return task;
    }
    return null;
};