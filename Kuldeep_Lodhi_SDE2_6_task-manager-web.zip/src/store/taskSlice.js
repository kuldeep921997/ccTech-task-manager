import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import * as taskService from '../services/taskService';

export const fetchTasksAsync = createAsyncThunk(
    'tasks/fetchTasks',
    async (_, { rejectWithValue }) => {
        try {
            const data = await taskService.fetchTasks();
            return data;
        } catch (error) {
            return rejectWithValue(error.response?.data?.error || 'Failed to fetch tasks');
        }
    }
);

export const createTaskAsync = createAsyncThunk(
    'tasks/createTask',
    async (taskData, { rejectWithValue }) => {
        try {
            const data = await taskService.createTask(taskData);
            return data;
        } catch (error) {
            return rejectWithValue(error.response?.data?.error || 'Failed to create task');
        }
    }
);

export const updateTaskAsync = createAsyncThunk(
    'tasks/updateTask',
    async ({ id, status }, { rejectWithValue }) => {
        try {
            const data = await taskService.updateTaskStatus(id, status);
            return data;
        } catch (error) {
            return rejectWithValue(error.response?.data?.error || 'Failed to update task');
        }
    }
);

const initialState = {
    tasks: [],
    loading: false,
    error: null,
    createLoading: false,
    updateLoading: false
};

const taskSlice = createSlice({
    name: 'tasks',
    initialState,
    reducers: {
        clearError: (state) => {
            state.error = null;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchTasksAsync.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchTasksAsync.fulfilled, (state, action) => {
                state.loading = false;
                state.tasks = action.payload;
            })
            .addCase(fetchTasksAsync.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            });

        builder
            .addCase(createTaskAsync.pending, (state) => {
                state.createLoading = true;
                state.error = null;
            })
            .addCase(createTaskAsync.fulfilled, (state, action) => {
                state.createLoading = false;
                state.tasks.push(action.payload);
            })
            .addCase(createTaskAsync.rejected, (state, action) => {
                state.createLoading = false;
                state.error = action.payload;
            });

        builder
            .addCase(updateTaskAsync.pending, (state) => {
                state.updateLoading = true;
                state.error = null;
            })
            .addCase(updateTaskAsync.fulfilled, (state, action) => {
                state.updateLoading = false;
                const index = state.tasks.findIndex(task => task.id === action.payload.id);
                if (index !== -1) {
                    state.tasks[index] = action.payload;
                }
            })
            .addCase(updateTaskAsync.rejected, (state, action) => {
                state.updateLoading = false;
                state.error = action.payload;
            });
    }
});

export const { clearError } = taskSlice.actions;
export default taskSlice.reducer;