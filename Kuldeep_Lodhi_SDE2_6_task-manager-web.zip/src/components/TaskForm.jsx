import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { createTaskAsync } from '../store/taskSlice';
import { TASK_STATUS } from '../types/taskTypes';

const TaskForm = () => {
    const [title, setTitle] = useState('');
    const [status, setStatus] = useState(TASK_STATUS.TODO);

    const dispatch = useDispatch();
    const { createLoading } = useSelector((state) => state.tasks);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!title.trim()) {
            alert('Please enter a task title');
            return;
        }

        dispatch(createTaskAsync({ title, status }));
        setTitle('');
        setStatus(TASK_STATUS.TODO);
    };

    return (
        <div style={styles.container}>
            <h2 style={styles.heading}>Add New Task</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
                <input
                    type="text"
                    placeholder="Enter task title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    style={styles.input}
                    disabled={createLoading}
                />

                <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    style={styles.select}
                    disabled={createLoading}
                >
                    <option value={TASK_STATUS.TODO}>Todo</option>
                    <option value={TASK_STATUS.IN_PROGRESS}>In Progress</option>
                    <option value={TASK_STATUS.DONE}>Done</option>
                </select>

                <button
                    type="submit"
                    style={styles.button}
                    disabled={createLoading}
                >
                    {createLoading ? 'Adding...' : 'Add Task'}
                </button>
            </form>
        </div>
    );
};

const styles = {
    container: {
        backgroundColor: '#f8f9fa',
        padding: '20px',
        borderRadius: '8px',
        marginBottom: '30px'
    },
    heading: {
        marginTop: 0,
        marginBottom: '15px',
        color: '#333'
    },
    form: {
        display: 'flex',
        gap: '10px',
        flexWrap: 'wrap'
    },
    input: {
        flex: '1',
        minWidth: '200px',
        padding: '10px',
        fontSize: '14px',
        border: '1px solid #ddd',
        borderRadius: '4px'
    },
    select: {
        padding: '10px',
        fontSize: '14px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        minWidth: '150px'
    },
    button: {
        padding: '10px 20px',
        fontSize: '14px',
        backgroundColor: '#007bff',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
    }
};

export default TaskForm;