import { useDispatch, useSelector } from 'react-redux';
import { updateTaskAsync } from '../store/taskSlice';
import { TASK_STATUS, STATUS_LABELS } from '../types/taskTypes';

const TaskColumn = ({ status, tasks }) => {
    const dispatch = useDispatch();
    const { updateLoading } = useSelector((state) => state.tasks);

    const handleStatusChange = (taskId, newStatus) => {
        dispatch(updateTaskAsync({ id: taskId, status: newStatus }));
    };

    const getColumnColor = () => {
        switch (status) {
            case TASK_STATUS.TODO:
                return '#dc3545';
            case TASK_STATUS.IN_PROGRESS:
                return '#ffc107';
            case TASK_STATUS.DONE:
                return '#28a745';
            default:
                return '#6c757d';
        }
    };

    return (
        <div style={{ ...styles.column, borderTopColor: getColumnColor() }}>
            <h3 style={styles.columnTitle}>
                {STATUS_LABELS[status]} ({tasks.length})
            </h3>

            <div style={styles.taskList}>
                {tasks.length === 0 ? (
                    <p style={styles.emptyMessage}>No tasks</p>
                ) : (
                    tasks.map((task) => (
                        <div key={task.id} style={styles.taskCard}>
                            <div style={styles.taskHeader}>
                                <h4 style={styles.taskTitle}>{task.title}</h4>
                                <span style={styles.taskId}>#{task.id}</span>
                            </div>

                            <p style={styles.taskDate}>
                                Created: {new Date(task.createdAt).toLocaleDateString()}
                            </p>

                            <div style={styles.statusSection}>
                                <label style={styles.label}>Change Status:</label>
                                <select
                                    value={task.status}
                                    onChange={(e) => handleStatusChange(task.id, e.target.value)}
                                    style={styles.statusSelect}
                                    disabled={updateLoading}
                                >
                                    <option value={TASK_STATUS.TODO}>Todo</option>
                                    <option value={TASK_STATUS.IN_PROGRESS}>In Progress</option>
                                    <option value={TASK_STATUS.DONE}>Done</option>
                                </select>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const styles = {
    column: {
        flex: '1',
        minWidth: '280px',
        maxWidth: '380px',
        height: 'calc(100vh - 280px)',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: '#fff',
        borderRadius: '8px',
        padding: '15px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        borderTop: '4px solid',
    },
    columnTitle: {
        marginTop: 0,
        marginBottom: '15px',
        fontSize: '18px',
        fontWeight: 'bold',
        color: '#333',
        flexShrink: 0
    },
    taskList: {
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        overflowY: 'auto',
        overflowX: 'hidden',
        flex: 1,
        paddingRight: '5px',
        scrollbarWidth: 'thin',
        scrollbarColor: '#888 #f1f1f1'
    },
    taskCard: {
        backgroundColor: '#f8f9fa',
        padding: '12px',
        borderRadius: '6px',
        border: '1px solid #e0e0e0',
        flexShrink: 0
    },
    taskHeader: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '8px'
    },
    taskTitle: {
        margin: 0,
        fontSize: '16px',
        color: '#333',
        wordBreak: 'break-word'
    },
    taskId: {
        fontSize: '12px',
        color: '#6c757d',
        fontWeight: 'bold',
        flexShrink: 0,
        marginLeft: '8px'
    },
    taskDate: {
        margin: '5px 0',
        fontSize: '12px',
        color: '#6c757d'
    },
    statusSection: {
        marginTop: '10px'
    },
    label: {
        display: 'block',
        fontSize: '12px',
        marginBottom: '5px',
        color: '#666'
    },
    statusSelect: {
        width: '100%',
        padding: '6px',
        fontSize: '13px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        cursor: 'pointer'
    },
    emptyMessage: {
        textAlign: 'center',
        color: '#999',
        fontSize: '14px',
        padding: '20px'
    }
};

export default TaskColumn;