import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTasksAsync } from '../store/taskSlice';
import { TASK_STATUS } from '../types/taskTypes';
import TaskColumn from './TaskColumn';

const TaskList = () => {
    const dispatch = useDispatch();
    const { tasks, loading, error } = useSelector((state) => state.tasks);

    useEffect(() => {
        dispatch(fetchTasksAsync());
    }, [dispatch]);

    const groupedTasks = {
        [TASK_STATUS.TODO]: tasks.filter(task => task.status === TASK_STATUS.TODO),
        [TASK_STATUS.IN_PROGRESS]: tasks.filter(task => task.status === TASK_STATUS.IN_PROGRESS),
        [TASK_STATUS.DONE]: tasks.filter(task => task.status === TASK_STATUS.DONE)
    };

    if (loading) {
        return <div style={styles.loading}>Loading tasks...</div>;
    }

    if (error) {
        return (
            <div style={styles.error}>
                <p>Error: {error}</p>
                <button onClick={() => dispatch(fetchTasksAsync())} style={styles.retryButton}>
                    Retry
                </button>
            </div>
        );
    }

    return (
        <div style={styles.container}>
            <TaskColumn status={TASK_STATUS.TODO} tasks={groupedTasks[TASK_STATUS.TODO]} />
            <TaskColumn status={TASK_STATUS.IN_PROGRESS} tasks={groupedTasks[TASK_STATUS.IN_PROGRESS]} />
            <TaskColumn status={TASK_STATUS.DONE} tasks={groupedTasks[TASK_STATUS.DONE]} />
        </div>
    );
};

const styles = {
    container: {
        display: 'flex',
        gap: '20px',
        justifyContent: 'center',
        alignItems: 'flex-start'
    },
    loading: {
        textAlign: 'center',
        padding: '40px',
        fontSize: '18px',
        color: '#666'
    },
    error: {
        textAlign: 'center',
        padding: '40px',
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '8px'
    },
    retryButton: {
        marginTop: '10px',
        padding: '10px 20px',
        backgroundColor: '#dc3545',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
    }
};

export default TaskList;